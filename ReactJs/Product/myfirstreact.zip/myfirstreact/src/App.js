import React, { Component } from 'react';
import list from './list.js';
import logo from './1.jpg';
import './App.css';
import { render } from '@testing-library/react';

function isSearchedBrand(searchBrand){
  return function(item)
  {
    return !searchBrand || item.brand.includes(searchBrand);
  }
}

function isSearchedColor(searchColor){
  return function(item)
  {
    return !searchColor || item.colour.includes(searchColor);
  }
}

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      list : list,
      searchBrand : '',
      searchCpolor : ''
    }
    this.removeItem = this.removeItem.bind(this);
    this.searchAvailability = this.searchAvailability.bind(this);
    this.searchBrand = this.searchBrand.bind(this);
    this.searchColor = this.searchColor.bind(this);
  }

  removeItem(id){
    console.log("removed");
    const updatedList = this.state.list.filter(item => item.id != id);
    this.setState({list : updatedList});
  }

  searchBrand(event){
    console.log(event);
    this.setState({searchBrand : event.target.value});
  }

  searchColor(event){
    console.log(event);
    this.setState({searchColor : event.target.value});
  }

  searchAvailability(event){
    console.log(event);
    const updatedList = this.state.list.filter(item => item.availability == 0);
    this.setState({list : updatedList});
  }

  render() {
    console.log(this);
    return (
      <div className="App">
        <form>
        <label htmlFor="brand">Brand: </label>
        <input type="text" onChange={this.searchBrand} /><br></br>
        <label htmlFor="color">Colour: </label>
        <input type="text" onChange={this.searchColor} /><br></br>
        <button type="button" onClick={this.searchAvailability}>Show Available! </button><br></br>
      </form><br></br> 
      {
        this.state.list.filter(isSearchedBrand(this.state.searchBrand)).filter(isSearchedColor(this.state.searchColor)).map(item =>
            <div key={item.id}>
              <img src={item.reference} alt="Image"></img>
              <p>{item.colour} | {item.brand} | {item.availability} | <button type = "button" onClick = { ()=> this.removeItem(item.id)}> Remove </button><br></br></p>
            </div>
          )
      }
    </div>
  );
  }
}

export default App;
/* <form>
        <label for="brand">Brand: </label>
        <input type="text" onChange={this.searchBrand} /><br></br>
        <label for="color">Colour: </label>
        <input type="text" onChange={this.searchColor} /><br></br>
        <button type="button" onClick={this.searchAvailability}>Show Available! </button><br></br>
      </form><br></br> */