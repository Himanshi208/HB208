import React, { Component } from 'react';
import list from './list.js';
import logo from './1.jpg';
import './App.css';
import { render } from '@testing-library/react';
/*import { useHistory } from 'react-router-dom'

const Root = () => {
  const history = useHistory()

  function useEffect ()  {
      return history.listen((location) => {
          console.log(`You changed the page to: ${location.pathname}`)
      })
  }

  return (
      <App />
  )
}*/

function isSearchedBrand(searchBrand){
  return function(item)
  {
    return !searchBrand || item.brand.includes(searchBrand);
  }
}

function isSearchedColor(searchColor){
  return function(item)
  {
    return !searchColor || item.colour.includes(searchColor);
  }
}

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      //list : list,
      list,
      searchBrand : '',
      searchColor : ''
    }
    this.removeItem = this.removeItem.bind(this);
    this.searchAvailability = this.searchAvailability.bind(this);
    this.searchBrand = this.searchBrand.bind(this);
    this.searchColor = this.searchColor.bind(this);
  }

  removeItem(id){
    console.log("removed");
    const updatedList = this.state.list.filter(item => item.id !== id);
    this.setState({list : updatedList});
  }

  searchBrand(event){
    console.log(event);
    this.setState({searchBrand : event.target.value});
  }

  searchColor(event){
    console.log(event);
    this.setState({searchColor : event.target.value});
  }

  searchAvailability(event){
    console.log(event);
    const updatedList = this.state.list.filter(item => item.availability === 0);
    this.setState({list : updatedList});
  }

  sortAscendingBrand = () => {
    const { brand } = this.state;
    const updatedList = this.state.list.sort((a, b) => a - b)
    this.setState({ list : updatedList });
  }

  /*sortDescendingBrand = () => {
    const { brand } = this.state;
    const updatedList = this.state.list.sort((a, b) => a - b).reverse()
    this.setState({ list : updatedList });
  }*/

  sortAscendingColor = () => {
    const { colour } = this.state;
    const updatedList = this.state.list.sort((a, b) => a - b)
    this.setState({ list : updatedList });
  }

  render() {
    const {list, searchBrand} = this.state;
    //const {list, searchColor} = this.state;
    console.log(this);
    return (
      <div className="App">
        { /* <Pagination
          activePage={this.state.activePage}
          itemsCountPerPage={4}
          totalItemsCount={20}
          pageRangeDisplayed={5}
          onChange={this.handlePageChange.bind(this)}
        /> */ }
        <Search 
        onChange={this.searchBrand} 
        value={searchBrand}
        onChangeColor={this.searchColor}
        onClick={this.searchAvailability}
        >Search Brand Here: </Search><br></br><br></br>
        <Table
        list={list}
        searchBrand = {searchBrand}
        searchColor = {this.state.searchColor}
        removeItem = {this.removeItem}
        />
        <button onClick={this.sortAscendingBrand}>Sort by Brand</button>&nbsp;&nbsp;
        <button onClick={this.sortAscendingColor}>Sort by Color</button><br></br>
    </div>
  );
  }
}

const Search = ({onChange,value,onChangeColor,onClick,children}) => 
<form>
{children}
<label htmlFor="brand"></label>
<input type="text" onChange={onChange} value={value}/><br></br>
<label htmlFor="color">Colour: </label>
<input type="text" onChange={onChangeColor} /><br></br><br></br>
<button type="button" onClick={onClick}>Show Available! </button><br></br>
</form>

const Table = ({list, searchBrand,searchColor,removeItem}) =>
<div>
  {
    list.filter(isSearchedBrand(searchBrand)).filter(isSearchedColor(searchColor)).map(item =>
    <div key={item.id}>
      <img src={item.reference} alt="Image"></img>
      <p>{item.colour} | {item.brand} | {item.availability} | <Button type="button" onClick={ ()=> removeItem(item.id) }>Remove</Button><br></br></p>
    </div>
    )
  }
</div>


/* class Search extends Component
{
  render (){
    const {onChange,value,onChangeColor,onClick,children} = this.props;
    return(
      <form>
        {children}
        <label htmlFor="brand"></label>
        <input type="text" onChange={onChange} value={value}/><br></br>
        <label htmlFor="color">Colour: </label>
        <input type="text" onChange={onChangeColor} /><br></br><br></br>
        <button type="button" onClick={onClick}>Show Available! </button><br></br>
      </form>
    )
  }
}

class Table extends Component{
  render(){
    const {list, searchBrand,searchColor,removeItem} = this.props;
    return(
      <div>
        {
        list.filter(isSearchedBrand(searchBrand)).filter(isSearchedColor(searchColor)).map(item =>
            <div key={item.id}>
              <img src={item.reference} alt="Image"></img>
              <p>{item.colour} | {item.brand} | {item.availability} | <Button type="button" onClick={ ()=> removeItem(item.id) }>Remove</Button><br></br></p>
            </div>
          )
        }
      </div>
    )
  }
}

 class Button extends Component{
  render(){
    const {onClick, children} = this.props;
    return(
    <button onClick = { onClick } > {children} </button>
    )
  }
} */

const Button = ({onClick, children}) => <button onClick = { onClick } > {children} </button>

export default App;
