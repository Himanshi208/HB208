const list=[
  {
    id:1,
    reference: "1.jpg",
    colour: "Yellow",
    brand: "Brand A",
    availability: 1
  },
  {
    id:2,
    reference: "2.jpg",
    colour: "Red",
    brand: "Brand B",
    availability: 0
  },
  {
    id:3,
    reference: "3.jpg",
    colour: "Green",
    brand: "Brand D",
    availability: 0
  },
  {
    id:4,
    reference: "4.jpg",
    colour: "Red",
    brand: "Brand A",
    availability: 1
  },
  {
    id:5,
    reference: "5.jpg",
    colour: "Blue",
    brand: "Brand B",
    availability: 0
  },
  {
    id:6,
    reference: "6.jpg",
    colour: "Green",
    brand: "Brand C",
    availability: 0
  },
  {
    id:7,
    reference: "7.jpg",
    colour: "Red",
    brand: "Brand C",
    availability: 1
  },
  {
    id:8,
    reference: "8.jpg",
    colour: "Blue",
    brand: "Brand D",
    availability: 0
  },
  {
    id:9,
    reference: "9.jpg",
    colour: "Yellow",
    brand: "Brand A",
    availability: 0
  },
  {
    id:10,
    reference: "10.jpg",
    colour: "Yellow",
    brand: "Brand B",
    availability: 1
  },
  {
    id:11,
    reference: "11.jpg",
    colour: "Green",
    brand: "Brand D",
    availability: 0
  },
  {
    id:12,
    reference: "12.jpg",
    colour: "Yellow",
    brand: "Brand D",
    availability: 0
  },
  {
    id:13,
    reference: "13.jpg",
    colour: "Blue",
    brand: "Brand A",
    availability: 0
  },
  {
    id:14,
    reference: "14.jpg",
    colour: "Blue",
    brand: "Brand D",
    availability: 0
  },
  {
    id:15,
    reference: "15.jpg",
    colour: "Green",
    brand: "Brand B",
    availability: 0
  },
  {
    id:16,
    reference: "16.jpg",
    colour: "Yellow",
    brand: "Brand B",
    availability: 1
  },
  {
    id:17,
    reference: "17.jpg",
    colour: "Green",
    brand: "Brand A",
    availability: 1
  },
  {
    id:18,
    reference: "18.jpg",
    colour: "Blue",
    brand: "Brand D",
    availability: 1
  },
  {
    id:19,
    reference: "19.jpg",
    colour: "Green",
    brand: "Brand C",
    availability: 0
  },
  {
    id:20,
    reference: "20.jpg",
    colour: "Yellow",
    brand: "Brand A",
    availability: 0
  }    
]

export default list;